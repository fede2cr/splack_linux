for cfgfile in access.conf httpd.conf magic mime.types srm.conf ; do
   if [ ! -f etc/apache/${cfgfile} ]; then
      cp -a etc/apache/${cfgfile}.default etc/apache/${cfgfile}
   fi
done
