/* No manual changes in this file */

static char rcsid[] = "$Id: version.c,v 1.6 2000/06/29 06:17:07 gerlof Exp gerlof $";
