/*
** This file describes all required include-files for both
** the atsadc- and the atsar-program.
*/

#include <sys/types.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/times.h>
#include <sys/utsname.h>
#include <stdio.h>
#include <malloc.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/socket.h>
#include "linuxstat.h"
#include <string.h>

#include "atsar.h"
