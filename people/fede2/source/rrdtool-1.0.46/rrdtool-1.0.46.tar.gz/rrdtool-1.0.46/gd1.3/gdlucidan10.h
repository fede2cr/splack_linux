
#ifndef _GDLUCIDAN10_H_
#define _GDLUCIDAN10_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Medium-R-Normal-Sans-10-100-75-75-M-60-ISO8859-1
	at Tue Jul 13 15:33:56 1999.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaNormal10;

#endif

