
#ifndef _GDLUCIDAB12_H_
#define _GDLUCIDAB12_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Bold-R-Normal-Sans-12-120-75-75-M-70-ISO8859-1
	at Tue Jul 13 15:35:50 1999.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaBold12;

#endif

