    VAR_CONFIG_DIR, DEF_CONFIG_DIR, &var_config_dir, 1, 0,
