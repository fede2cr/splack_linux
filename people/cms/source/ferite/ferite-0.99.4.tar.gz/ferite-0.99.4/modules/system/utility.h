
/* bootids: 
 * Assigned at bootstrap: once assigned, they are R/O.
 * User inaccessable, internal-use only.
 * These are what we'll respect as original, master id's.
 */
/*
typedef struct 
{
    char	scriptcheck;	// internal flag...
    long	ruid, rgid,	// Real..	(users -  id/group)
    		euid, egid,	// Effective..	(engine - set[ug]id?)
    		tuid, tgid;	// Script..	(script - owner/group)
    char 	*logid, *name,	// getpwuid() goodies to remember..
    		*home, *shell;
    char	**groups;	// set of groups you belong to.
    unsigned	*gids;		// parallel above.
} IDS;

extern IDS bootids;*/
