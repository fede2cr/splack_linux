/*
 * Copyright (C) 2000-2001 Chris Ross and Evan Webb
 * Copyright (C) 1999-2000 Chris Ross
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *   
 * The above copyright notice and this permission notice shall be included in
 * all copies of the Software, its documentation and marketing & publicity 
 * materials, and acknowledgment shall be given in the documentation, materials
 * and software packages that this Software was used.
 *    
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER 
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

void                __ferite_uarray_destroy( FeriteScript *script,FeriteUnifiedArray *array);
FeriteIterator     *__ferite_create_iterator( FeriteScript *script );
FeriteHashBucket   *__ferite_hash_add_get( FeriteScript *script, FeriteHash *hash, char *key, void *data);
void                __ferite_uarray_add( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *var, char *id, int index);
FeriteVariable     *__ferite_uarray_get( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *var);
void                __ferite_uarray_clean( FeriteScript *script,FeriteUnifiedArray *array);
FeriteUnifiedArray *__ferite_uarray_dup( FeriteScript *script,FeriteUnifiedArray *array, void *(*ddup)( FeriteScript *script, FeriteVariable *data));
FeriteVariable     *__ferite_uarray_get( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *var);
void                __ferite_uarray_add( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *var, char *id, int index);
FeriteVariable     *__ferite_uarray_op( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *index, void *rhs);
FeriteVariable     *__ferite_uarray_item_to_var( FeriteScript *script,FeriteArrayItem *item);
FeriteHashBucket   *__ferite_uarray_walk( FeriteScript *script,FeriteUnifiedArray *array, FeriteIterator *iter);
void                __ferite_uarray_del_var( FeriteScript *script,FeriteUnifiedArray *array, FeriteVariable *i);
void                __ferite_uarray_del_index( FeriteScript *script,FeriteUnifiedArray *array, int i);

FeriteVariable     *__ferite_uarray_pop( FeriteScript *script,FeriteUnifiedArray *array);
void                __ferite_uarray_push( FeriteScript *script,FeriteUnifiedArray *array, void *var);
void                __ferite_uarray_unshift( FeriteScript *script,FeriteUnifiedArray *array, void *var);
FeriteVariable     *__ferite_uarray_shift( FeriteScript *script,FeriteUnifiedArray *array);
FeriteHashBucket   *__ferite_uarray_walk_linear( FeriteScript *script,FeriteUnifiedArray *array, FeriteIterator *iter);
#define AIV(item1)  __ferite_uarray_item_to_var( script, item1 )
