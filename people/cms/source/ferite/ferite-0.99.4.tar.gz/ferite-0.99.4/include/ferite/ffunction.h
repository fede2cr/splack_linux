/*
 * Copyright (C) 2000-2001 Chris Ross and Evan Webb
 * Copyright (C) 1999-2000 Chris Ross
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *   
 * The above copyright notice and this permission notice shall be included in
 * all copies of the Software, its documentation and marketing & publicity 
 * materials, and acknowledgment shall be given in the documentation, materials
 * and software packages that this Software was used.
 *    
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER 
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef _FERITE_FUNCTION_H_
#define _FERITE_FUNCTION_H_

#define FNC_IS_INTRL 1
#define FNC_IS_EXTRL 2

FeriteFunction *__ferite_create_internal_function( FeriteScript *script, char *name );
FeriteFunction *__ferite_create_external_function( FeriteScript *script, char *name, void *(*funcPtr)(FeriteScript *, FeriteVariable **), char *description, int is_static );
FeriteFunction *__ferite_function_get( FeriteScript *script, char *name );
FeriteOp **__ferite_function_get_compiled_code( FeriteScript *script, char *name );
void __ferite_delete_function_list( FeriteScript *script, FeriteFunction *funcs );
void __ferite_delete_function_hash( FeriteScript *script, FeriteHash *hash );
int __ferite_check_params( FeriteScript *script, FeriteVariable **params, FeriteParameterRecord **signature );

#endif /* _FERITE_FUNCTION_H_ */
