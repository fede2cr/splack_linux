/*
   The Ferite library loader, dlfnc edition. Uses the system dl
   as the lib loader
*/

#include "../config.h"

#ifdef USE_DLFCN

# include <dlfcn.h>
# include "triton.h"

LIB_INIT {
   return;
}

LIB_DEINIT {
   return;
}

LIB_EXT {
   return ".so";
}

LIB_OPEN {
   return dlopen(path, RTLD_LAZY | RTLD_GLOBAL);
}

LIB_SYM {
   return dlsym(handle, symbol);
}

LIB_CLOSE {
   return dlclose(handle);
}

LIB_ERROR {
   return "";
}

#endif
