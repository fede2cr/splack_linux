//@line 2 "/builds/tinderbox/Fx-Mozilla1.8-release/Linux_2.4.21-27.0.4.EL_Depend/mozilla/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "release");
