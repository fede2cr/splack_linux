#ifndef _SNK_H
#define _SNK_H

#ifdef SNK
extern int issnkregistered(char * u, void * k);
extern int snkauth(char *u);

#endif /* SNK */
#endif /* _SNK_h */

