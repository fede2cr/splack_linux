( cd sbin ; rm -rf dip )
( cd sbin ; ln -sf dip-3.3.7p dip )
( cd sbin ; rm -rf diplogin )
( cd sbin ; ln -sf dip-3.3.7p diplogin )
