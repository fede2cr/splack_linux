//@line 2 "/builds/tinderbox/Tb-Mozilla1.8-Release/Linux_2.4.18-14_Depend/mozilla/mail/app/profile/channel-prefs.js"
pref("app.update.channel", "release");
