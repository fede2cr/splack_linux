// Default start page
pref("mailnews.start_page.url", "http://%LOCALE%.www.mozilla.com/%LOCALE%/%APP%/%VERSION%/start/");

// first launch welcome page
pref("mailnews.start_page.welcome_url", "http://%LOCALE%.www.mozilla.com/%LOCALE%/%APP%/%VERSION%/start/");

// start page override to load after an update
pref("mailnews.start_page.override_url", "http://%LOCALE%.www.mozilla.com/%LOCALE%/%APP%/%VERSION%/start/");
