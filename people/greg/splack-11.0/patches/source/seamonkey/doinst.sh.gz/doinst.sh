# If there's no mozilla here, then take over:
if [ ! -r usr/bin/mozilla ]; then
  ( cd usr/bin ; ln -sf seamonkey mozilla )
fi
# Hopefully this won't break everything.  ;-)
if ! grep /usr/lib/seamonkey etc/ld.so.conf 1> /dev/null 2> /dev/null ; then
  echo "/usr/lib/seamonkey" >> etc/ld.so.conf
fi
if [ -x /sbin/ldconfig ]; then
  /sbin/ldconfig 2> /dev/null
fi
# These links just cause problems now...
( cd usr/lib/pkgconfig
  for file in mozilla-gtkmozembed.pc mozilla-js.pc mozilla-nspr.pc mozilla-nss.pc mozilla-plugin.pc mozilla-xpcom.pc ; do
    if [ -L $file ]; then
      rm -f $file
    fi
  done
)
( cd usr/lib
  for file in libmozjs.so libnspr4.so libnss3.so libplc4.so libplds4.so libsmime3.so libsoftokn3.so libssl3.so ; do
   if [ -L $file ]; then
      rm -f $file
    fi
  done
)
