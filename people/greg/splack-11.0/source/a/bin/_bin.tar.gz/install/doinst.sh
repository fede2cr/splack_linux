config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

#config etc/file/magic.mgc.new
#config etc/file/magic.mime.mgc.new
# Since /etc/file/magic has once again changed to a new incompatible format,
# it doesn't make much sense to worry about if a config file (sort of) that
# someone has customized is not overwritten if it's not going to work in
# any case.  Leaving a broken /etc/file/magic in place for all those
# (insert auto-upgrade tool here) users is a nightmare scenario.  As always,
# folks need to be responsible for saving important files in /etc before
# they go blindly upgrading packages.
#config etc/file/magic.mime.new
#config etc/file/magic.new

# Don't let an upgrade nuke someone's old /etc/magic files:
# (of course, if they really have files in these locations they will be
# so ancient as to be of historical interest only...)
if [ -f etc/magic -a ! -L etc/magic ]; then
  mv etc/magic etc/magic.old
fi
if [ -f etc/magic.mime -a ! -L etc/magic.mime ]; then
  mv etc/magic.mime etc/magic.mime.old
fi

( cd etc ; rm -rf magic )
( cd etc ; ln -sf file/magic magic )
( cd etc ; rm -rf magic.mime )
( cd etc ; ln -sf file/magic.mime magic.mime )
( cd usr/bin ; rm -rf uncompress )
( cd usr/bin ; rm -rf uncompress )
( cd usr/bin ; ln -sf compress uncompress )
( cd usr/bin ; rm -rf rpm2tgz )
( cd usr/bin ; ln -sf rpm2targz rpm2tgz )
( cd usr/lib ; rm -rf makewhatis )
( cd usr/lib ; ln -sf /usr/sbin/makewhatis makewhatis )
( cd sbin ; rm -rf fsck.hpfs )
( cd sbin ; ln -sf /bin/true fsck.hpfs )
( cd sbin ; rm -rf fsck.msdos )
( cd sbin ; ln -sf /bin/true fsck.msdos )
( cd sbin ; rm -rf fsck.umsdos )
( cd sbin ; ln -sf /bin/true fsck.umsdos )
( cd sbin ; rm -rf mkfs.msdos )
( cd sbin ; ln -sf mkdosfs mkfs.msdos )
( cd bin ; rm -rf red )
( cd bin ; ln -sf ed red )
( cd bin ; rm -rf compress )
( cd bin ; ln -sf /usr/bin/compress compress )
( cd usr/bin ; rm -rf which )
( cd usr/bin ; ln -sf ../../bin/which which )
