#ifndef _version_h
#define _version_h

#define	VERSION			"2.10"
#define VERSION_DATE	"22 Sep 2003"

#endif  /* _version_h */

