#!/bin/sh

i=0
inc=128

while :
do
    i=$(($i+$inc))
    echo "B: $i"
    time src/slocate -b $i >/dev/null
    echo "-------------"
    if [ $i -gt 16384 ] ; then
        break
    fi
    
done
