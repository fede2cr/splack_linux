/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
#define VERSION_MAJOR 22
#define VERSION_MINOR 7
#define VERSION_EDIT  ".1"
#define VERSION_DATE "17-Sep-2005"

#endif
