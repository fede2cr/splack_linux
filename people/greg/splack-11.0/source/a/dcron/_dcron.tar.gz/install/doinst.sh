if [ ! -r var/spool/cron/crontabs/root ]; then
  mv var/spool/cron/crontabs/root.new var/spool/cron/crontabs/root
else
  mv var/spool/cron/crontabs/root.new var/spool/cron/root.crontab.sample
fi
