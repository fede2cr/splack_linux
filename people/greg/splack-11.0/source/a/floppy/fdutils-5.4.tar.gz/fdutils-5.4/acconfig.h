
/***** begin user configuration section *****/

/* Define this if you fdmount to be usable only by the 'floppy' group */
#undef FLOPPY_ONLY


