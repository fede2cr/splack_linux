const char *mversion="pre6-3.9.8";
const char *mdate = "27 May 2001";
