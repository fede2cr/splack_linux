#!/bin/sh
config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
config etc/rc.d/rc.pcmcia.new
config etc/pcmcia/config.opts.new
config etc/pcmcia/ftl.opts.new
config etc/pcmcia/ide.opts.new
config etc/pcmcia/ieee1394.opts.new
config etc/pcmcia/memory.opts.new
config etc/pcmcia/network.opts.new
config etc/pcmcia/parport.opts.new
config etc/pcmcia/scsi.opts.new
config etc/pcmcia/serial.opts.new
config etc/pcmcia/wireless.opts.new
