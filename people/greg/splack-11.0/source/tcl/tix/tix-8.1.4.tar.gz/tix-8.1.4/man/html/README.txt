RCS $Id: README.txt,v 1.1.2.2 2001/12/09 03:25:15 idiscovery Exp $

This directory contains HTML version of the Tix manual pages. All the
HTML files are auto-generated, so do not edit them directly. If you
need to make a change, edit the Nroff sources in the parent directory.

If there are no other files in this directory except this README.txt
file, you probably have a checked-out copy of the Tix CVS tree. See
the file ../GNUmakefile about how to generate the HTML files.

