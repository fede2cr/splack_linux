/* Make the library identifiable with the RCS ident command.  */
#if 0
static char *version_string = "\n$Version: GNU termcap 1.2-MvS-1.1 $\n";
#else
static char *version_string = "\n$Version: GNU termcap 1.2.4 (Linux termcap 2.0.8) $\n";
#endif
