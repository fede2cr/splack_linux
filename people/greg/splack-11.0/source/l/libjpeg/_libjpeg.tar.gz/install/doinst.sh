( cd usr/lib ; rm -rf libjpeg.so.62 )
( cd usr/lib ; ln -sf libjpeg.so.62.0.0 libjpeg.so.62 )
( cd usr/lib ; rm -rf libjpeg.so )
( cd usr/lib ; ln -sf libjpeg.so.62 libjpeg.so )
