( cd usr/X11R6/lib ; rm -rf libXaw3d.so.7 )
( cd usr/X11R6/lib ; ln -sf libXaw3d.so.7.0 libXaw3d.so.7 )
( cd usr/X11R6/lib ; rm -rf libXaw3d.so )
( cd usr/X11R6/lib ; ln -sf libXaw3d.so.7 libXaw3d.so )
# This is for backwards compatability (on Slackware libXaw3d.so.6
# is also Xaw3d-1.5)
( cd usr/X11R6/lib ; rm -rf libXaw3d.so.6 )
( cd usr/X11R6/lib ; ln -sf libXaw3d.so.7.0 libXaw3d.so.6 )
