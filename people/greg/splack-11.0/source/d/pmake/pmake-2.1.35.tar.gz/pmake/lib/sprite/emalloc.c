/* 
 * emalloc.c --
 *	Error-checking memory allocators.
 */

#ifndef lint
static char rcsid[] = "$Id: emalloc.c,v 1.1 1993/01/05 22:02:57 stolcke Exp $ SPRITE (Berkeley)";
#endif /* not lint */

#include <stdio.h>
#include "sprite.h"

/*
 * emalloc --
 *      malloc, but die on error.
 */
char *
emalloc(len)
    unsigned int len;
{
    char *p;

    if (!(p = malloc(len)))
	enomem ();
    return (p);
}

/*
 * erealloc --
 *      realloc, but die on error.
 */
char *
erealloc(ptr, len)
    char *ptr;
    unsigned int len;
{
    char *p;

    if (!(p = realloc(ptr, len)))
	enomem ();
    return (p);
}

