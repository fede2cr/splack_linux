/* 
 * enomem.c --
 *	Abort for memory allocators.
 */

#ifndef lint
static char rcsid[] = "$Id: enomem.c,v 1.1 1993/01/05 22:02:57 stolcke Exp $ SPRITE (Berkeley)";
#endif /* not lint */

#include <stdio.h>
#include "sprite.h"

extern int errno;

/*
 * enomem --
 *      die when out of memory.
 */
void
enomem()
{
    (void)fprintf(stderr, "%s\n", strerror(errno));
    exit(2);
}

