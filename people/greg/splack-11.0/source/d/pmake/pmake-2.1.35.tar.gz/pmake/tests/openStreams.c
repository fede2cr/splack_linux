
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
extern int errno;

main()
{
    int	    	  	i;
    struct stat buf;
    
    printf("Open streams:");
    for (i = 0; i < 32; i++) {
	if (fstat(i, &buf) >= 0) {
	    printf(" %d", i);
	} else if (errno != EBADF) {
	    extern char *sys_errlist[];
	    
	    printf(" error on %d: %s", i, sys_errlist[errno]);
	}
    }
    printf("\n");
    exit(0);
}
