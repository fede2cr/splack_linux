#include "syscalls.h"

_syscall1(int,exit,int,exitcode)
