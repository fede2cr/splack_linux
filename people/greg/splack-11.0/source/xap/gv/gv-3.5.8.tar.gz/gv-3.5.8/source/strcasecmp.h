extern int strcasecmp(
#if NeedFunctionPrototypes
    const char*,
    const char*
#endif
);  

#if 0 /* unused ###jp### */
extern int strncasecmp(
#if NeedFunctionPrototypes
    const char*,
    const char*,
    size_t
#endif
);  
#endif
