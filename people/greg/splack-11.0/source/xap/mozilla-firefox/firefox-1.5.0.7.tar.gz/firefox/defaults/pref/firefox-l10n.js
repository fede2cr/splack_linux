//@line 36 "/builds/tinderbox/Fx-Mozilla1.8.0-Release/Linux_2.4.21-37.EL_Depend/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

//@line 38 "/builds/tinderbox/Fx-Mozilla1.8.0-Release/Linux_2.4.21-37.EL_Depend/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
