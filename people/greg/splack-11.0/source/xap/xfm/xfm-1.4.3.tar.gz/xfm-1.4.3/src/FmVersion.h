#ifndef FmVersion_h
#define FmVersion_h
#define XFMVERSION "1.4.3"
/* changes of minor version and/or patchlevel
 * don't require a new app-defaults file
 */
#define XFMMINORVERSION ""
#endif

