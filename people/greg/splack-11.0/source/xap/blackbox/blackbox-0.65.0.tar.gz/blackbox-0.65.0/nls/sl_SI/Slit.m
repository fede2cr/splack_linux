$set 7 #Slit

$ #SlitTitle
# Re�a
$ #SlitDirection
# Smer re�e
$ #SlitPlacement
# Lega re�e
