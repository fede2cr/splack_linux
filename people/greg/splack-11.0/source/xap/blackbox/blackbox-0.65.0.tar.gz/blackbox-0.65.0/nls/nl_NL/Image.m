$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: kan pixmap niet aanmaken\n
$ #ErrorCreatingXImage
# BImage::renderXImage: kan XImage niet aanmaken\n
$ #UnsupVisual
# BImage::renderXImage: niet ondersteunde visual\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: kan pixmap niet aanmaken\n
$ #InvalidColormapSize
# BImageControl::BImageControl: ongeldige grootte kleurenmap %d (%d/%d/%d) - verkleind\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: kan geen kleurenmap aanmaken\n
$ #ColorAllocFail
# BImageControl::BImageControl: kan kleur %d/%d/%d niet aanmaken\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - %d pixmaps verwijderd\n
$ #PixmapCacheLarge
# BImageControl::renderImage: cache is te groot, leeggemaakt\n
$ #ColorParseError
# BImageControl::getColor: fout bij lezen kleur: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: fout bij aanmaken kleur: '%s'\n
