$set 16 #bsetroot

$ #MustSpecify
# %s: erro: necessario especificar uma das op��es: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        conex�o com video\n\
  -mod <x> <y>             modula padr�o\n\
  -foreground, -fg <color> modula cor do primeiro plano\n\
  -background, -bg <color> modula cor do segundo plano\n\
  -gradient <texture>      textura gradiente\n\
  -from <color>            cor de inicio do gradiente\n\
  -to <color>              com do fim do gradiente\n\
  -solid <color>           cor solida\n\
  -help                    mostra este texto de ajuda e sai\n
