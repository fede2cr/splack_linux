$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: Fehler bei der Abfrage des X Servers.\n \
ein anderer Windowmanager benutzt Display %s bereits.\n
$ #ManagingScreen
# BScreen::BScreen: Verwaltung von Bildschirm %d mit Visual 0x%lx, Tiefe %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): Kann Font '%s' nicht finden\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): Kann Standard Font nicht finden.\n
$ #EmptyMenuFile
# %s: leere Menu Datei\n
$ #xterm
# xterm
$ #Restart
# Neustart
$ #Exit
# Beenden
$ #EXECError
# BScreen::parseMenuFile: [exec] Fehler, kein Menu Eintrag und/oder Befehl definiert.\n
$ #EXITError
# BScreen::parseMenuFile: [exit] Fehler, kein Menu Eintrag definiert\n
$ #STYLEError
# BScreen::parseMenuFile: [style] Fehler, kein Menu Eintrag und/oder Datei definiert\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] Fehler, kein Menu Eintrag definiert\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] Fehler, kein Dateiname definiert\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] Fehler, '%s' ist keine normale Datei\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] Fehler, kein Menu Eintrag definiert\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] Fehler, kein Menu Eintrag definiert\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] Fehler, kein Menu Eintrag definiert\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Fehler, kein Verzeichnis definiert\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Fehler, '%s' ist kein Verzeichnis\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Fehler, '%s' existiert nicht\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] Fehler, kein Menu Eintrag definiert\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

