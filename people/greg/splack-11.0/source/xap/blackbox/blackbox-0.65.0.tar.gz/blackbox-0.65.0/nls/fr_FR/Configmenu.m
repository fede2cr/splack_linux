$set 3 #Configmenu

$ #ConfigOptions
# Options de configuration
$ #FocusModel
# Mode d'attribution du clavier
$ #WindowPlacement
# Disposition des fen�tres
$ #ImageDithering
# Lissage des images
$ #OpaqueMove
# D�placement opaque des fen�tres
$ #FullMax
# Maximisation compl�te
$ #FocusNew
# Attribuer le clavier � la nouvelle fen�tre
$ #FocusLast
# Attribuer le clavier en changeant d'espace de travail
$ #DisableBindings
# D�sactiver les modificateurs avec V�rouillage D�filement
$ #ClickToFocus
# Cliquer pour obtenir le clavier
$ #SloppyFocus
# Attribution du clavier souple
$ #AutoRaise
# Premier plan automatique
$ #ClickRaise
# Cliquer pour mettre au premier plan
$ #SmartRows
# Disposition fut�e (Lignes)
$ #SmartCols
# Disposition fut�e (Colonnes)
$ #Cascade
# Disposition en cascade
$ #LeftRight
# De gauche � droite
$ #RightLeft
# De droite � gauche
$ #TopBottom
# De haut en bas
$ #BottomTop
# De bas en haut
