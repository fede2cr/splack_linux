$set 14 #main

$ #RCRequiresArg
# fel: '-rc' kr�ver ett argument\n
$ #DISPLAYRequiresArg
# fel: '-display' kr�ver ett argument\n
$ #WarnDisplaySet
# varning: kunde inte s�tta variabeln 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tanv�nd sk�rmanslutning.\n\
  -rc <string>\t\t\tanv�nd alternativ resursfil.\n\
  -version\t\t\tvisa version och avsluta.\n\
  -help\t\t\t\tvisa denna hj�lptext och avsluta.\n\n
$ #CompileOptions
# Kompilerad med:\n\
  Avlusning\t\t\t%s\n\
  Form:\t\t\t\t%s\n\
  8bpp ordnad dithering:\t%s\n\n
