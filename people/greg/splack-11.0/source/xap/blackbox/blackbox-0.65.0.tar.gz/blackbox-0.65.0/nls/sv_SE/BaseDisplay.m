$set 1 #BaseDisplay

$ #XError
# %s:  X-fel: %s(%d) opkod %d/%d\n  resurs 0x%lx\n
$ #SignalCaught
# %s: signal %d f�ngad\n
$ #ShuttingDown
# st�nger ner\n
$ #Aborting
# avbryter... dumpar k�rna\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: anslutning till X server misslyckades.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: kunde inte markera sk�rmanslutning som st�ng-vid-exekvering\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): tar bort d�ligt f�nster fr�n h�ndelsek�n\n
