$set 8 #Toolbar

$ #NoStrftimeLength
# 00:00000
$ #NoStrftimeDateFormat
# %02d/%02d/%02d
$ #NoStrftimeDateFormatEu
# %02d.%02d.%02d
$ #NoStrftimeTimeFormat24
#  %02d:%02d 
$ #NoStrftimeTimeFormat12
# %02d:%02d %sm
$ #NoStrftimeTimeFormatP
# p
$ #NoStrftimeTimeFormatA
# a
$ #ToolbarTitle
# Verkt�ylinje
$ #EditWkspcName
# Endre navn p� gjeldende skrivebord
$ #ToolbarPlacement
# Verkt�ylinje-plassering
