$set 10 #Windowmenu

$ #SendTo
# Skicka till...
$ #Shade
# Skugga
$ #Iconify
# Ikonifiera
$ #Maximize
# Maximera
$ #Raise
# H�j
$ #Lower
# S�nk
$ #Stick
# Klibbig
$ #KillClient
# D�da klient
$ #Close
# St�ng
