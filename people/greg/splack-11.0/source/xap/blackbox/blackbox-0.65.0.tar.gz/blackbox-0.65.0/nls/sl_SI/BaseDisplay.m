$set 1 #BaseDisplay

$ #XError
# %s:  Napaka v sistemu oken X: %s(%d) operacijska koda %d/%d\n  vir 0x%lx\n
$ #SignalCaught
# %s: prejet signal %d\n
$ #ShuttingDown
# zaustavitev\n
$ #Aborting
# prekinitev... izmet posmrtnih ostankov core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: neuspe�na povezava do stre�nika X.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: povezave do prikazovalnika ni mo� pripraviti do samodejne prekinitve ob zaustavitvi\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): pokvarjeno okno je odstranjeno iz dogodkovne vrste\n
