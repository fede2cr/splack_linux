$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: Erstelle 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres versagt\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: kann keinen Bildschirm f�r root window 0x%lx finden\n
$ #Unnamed
# Ohne Titel
$ #MapRequest
# BlackboxWindow::mapRequestEvent() von 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: 0x%lx nun Child des 0x%lx\n
