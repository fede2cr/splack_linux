$set 16 #bsetroot

$ #MustSpecify
# %s: error: debe especificarse uno entre: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        conexi�n de despliegue\n\
  -mod <x> <y>             dise�o de modula\n\
  -foreground, -fg <color> color de primer plano de modula\n\
  -background, -bg <color> color de fondo de modula\n\n\
  -gradient <texture>      textura del gradiente\n\
  -from <color>            color inicial del gradiente\n\
  -to <color>              color final del gradiente\n\n\
  -solid <color>           color s�lido\n\n\
  -help                    Imprimir este texto de ayuda y salir\n
