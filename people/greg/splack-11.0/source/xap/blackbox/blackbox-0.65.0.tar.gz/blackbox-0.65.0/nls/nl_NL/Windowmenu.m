$set 10 #Windowmenu

$ #SendTo
# Verplaatsen naar ...
$ #Shade
# Alleen titel
$ #Iconify
# Minimaliseren
$ #Maximize
# Maximaliseren
$ #Raise
# Voorgrond
$ #Lower
# Achtergrond
$ #Stick
# Altijd zichtbaar
$ #KillClient
# Afbreken
$ #Close
# Sluiten
