$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Slit retning
$ #SlitPlacement
# Slit placering
