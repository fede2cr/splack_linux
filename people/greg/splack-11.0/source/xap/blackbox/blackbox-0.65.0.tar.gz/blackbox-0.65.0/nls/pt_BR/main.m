$set 14 #main

$ #RCRequiresArg
# erro: '-rc' requer um argumento\n
$ #DISPLAYRequiresArg
# erro: '-display' requer um argumento\n
$ #WarnDisplaySet
# aviso: n�o foi possivel setar a variavel de ambiente 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tusar conex�o com o display.\n\
  -rc <string>\t\t\tusar arquivo alternativo de recursos.\n\
  -version\t\t\texibe a versao e sair.\n\
  -help\t\t\t\texibe este texto de ajuda e sair.\n\n
$ #CompileOptions
# Op��es em tempo de compila��o:\n\
  Depura��o:\t\t\t%s\n\
  Forma:\t\t\t%s\n\
  Simula��o Ordenada de Cores em 8bpp:\t%s\n\n
