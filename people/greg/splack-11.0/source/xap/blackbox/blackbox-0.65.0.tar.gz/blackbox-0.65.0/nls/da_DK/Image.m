$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: fejl ved skabelse af pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: fejl ved skabelse af XImage\n
$ #UnsupVisual
# BImage::renderXImage: ikke support for farvedybden\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: fejl ved skabelse af pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: ugyldigt farvekort st�rrelse %d (%d/%d/%d) - reducing\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: fejl ved allokering af farvekort\n
$ #ColorAllocFail
# BImageControl::BImageControl: fejl ved allokering af farve %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - sletter %d pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: cache er for stor, gennemtvinger rensning\n
$ #ColorParseError
# BImageControl::getColor: farvefejl: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: farveallokeringsfejl: '%s'\n
