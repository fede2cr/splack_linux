$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: nie znaleziono ekran�w, kt�rymi mo�na by by�o zarz�dza�.\n
$ #MapRequest
# Blackbox::process_event: MapRequest dla 0x%lx\n
