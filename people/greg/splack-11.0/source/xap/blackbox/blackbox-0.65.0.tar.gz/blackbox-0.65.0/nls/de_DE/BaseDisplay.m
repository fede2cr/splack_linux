$set 1 #BaseDisplay

$ #XError
# %s:  X Fehler: %s(%d) opcodes %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: Signal %d erhalten\n
$ #ShuttingDown
# Shutdown\n
$ #Aborting
# Abbruch... dumping core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: Verbindung mit X Server versagt.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: kann die Display Verbindung nicht als 'close-on-exec' markieren\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): Entfernung des inkorrekten Fensters aus der 'Event Queue'\n
