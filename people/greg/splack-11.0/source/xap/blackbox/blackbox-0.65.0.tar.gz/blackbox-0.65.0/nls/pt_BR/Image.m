$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: erro criando pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: erro criando XImage\n
$ #UnsupVisual
# BImage::renderXImage: visual n�o suportado\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: erro criando pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: tamanho invalido de mapa de cores %d (%d/%d/%d) - reduzindo\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: erro determinando mapa de cores\n
$ #ColorAllocFail
# BImageControl::BImageControl: falha em alocar cor %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: cache de pixmap - liberando pixmaps %d\n
$ #PixmapCacheLarge
# BImageControl::renderImage: cache est� grande, for�ando desaloca��o\n
$ #ColorParseError
# BImageControl::getColor: erro ao analizar cor: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: erro ao alocar cor: '%s'\n
