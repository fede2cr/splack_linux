$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: ingen h�ndterbare sk�rme fundet, afslutter\n
$ #MapRequest
# Blackbox::process_event: MapRequest for 0x%lx\n
