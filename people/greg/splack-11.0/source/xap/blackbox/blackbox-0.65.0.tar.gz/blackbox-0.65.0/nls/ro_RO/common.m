$set 15 #Common

$ #Yes
# Da
$ #No
# Nu

$ #DirectionTitle
# Directie
$ #DirectionHoriz
# Orizontal
$ #DirectionVert
# Vertical

$ #AlwaysOnTop
# Intotdeauna deasupra

$ #PlacementTitle
# Pozitie
$ #PlacementTopLeft
# Stanga sus
$ #PlacementCenterLeft
# Stanga centru
$ #PlacementBottomLeft
# Stanga jos
$ #PlacementTopCenter
# Mijloc sus
$ #PlacementBottomCenter
# Mijloc jos
$ #PlacementTopRight
# Dreapta sus
$ #PlacementCenterRight
# Dreapta centru
$ #PlacementBottomRight
# Dreapta jos

$ #AutoHide
# Ascundere automata
