$set 1 #BaseDisplay

$ #XError
# %s: errore di X: %s(%d) opcodes %d/%d\n  risorsa 0x%lx\n
$ #SignalCaught
# %s: segnale %d intercettato\n
$ #ShuttingDown
# arresto del programma\n
$ #Aborting
# Annullamento...generazione file core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: connessione al server X fallita.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: non e' possibile contrassegnare la connessione al display come close-on-exec\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): rimozione finestra difettosa dalla coda degli eventi\n
