$set 12 #Workspacemenu

$ #WorkspacesTitle
# Werkbladen
$ #NewWorkspace
# Nieuw werkblad
$ #RemoveLast
# Verwijder laatste werkblad
