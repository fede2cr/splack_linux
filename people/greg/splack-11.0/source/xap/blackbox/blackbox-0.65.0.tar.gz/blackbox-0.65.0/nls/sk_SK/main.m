$set 14 #main

$ #RCRequiresArg
# chyba: '-rc' vy�aduje argument\n
$ #DISPLAYRequiresArg
# chyba: '-display' vy�aduje argument\n
$ #WarnDisplaySet
# varovanie: nie je mo�n� nastavi� premenn� prostredia 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tpou�ije sa pripojenie k zadan�mu displeju.\n\
  -rc <string>\t\t\tpou�ije sa alternat�vny konfigura�n� s�bor.\n\
  -version\t\t\tzobraz� verziu a skon��.\n\
  -help\t\t\t\tzobraz� t�to n�povedu a skon��.\n\n
$ #CompileOptions
# Nastavenia v �ase kompil�cie:\n\
  Ladenie\t\t\t%s\n\
  Shape:\t\t\t%s\n\
  8bpp Ordered Dithering:\t%s\n\n
