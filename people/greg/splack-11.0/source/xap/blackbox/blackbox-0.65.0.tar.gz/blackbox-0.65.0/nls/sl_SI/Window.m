$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: izdelujem 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: neuspe�en XGetWindowAttributres\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: zaslona za korensko okno 0x%lx ni mo� najti\n
$ #Unnamed
# Neimenovano
$ #MapRequest
# BlackboxWindow::mapRequestEvent() za 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() za 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::unmapnotifyEvent: ponovno priklju�eno 0x%lx korenskemu oknu 0x%lx\n
