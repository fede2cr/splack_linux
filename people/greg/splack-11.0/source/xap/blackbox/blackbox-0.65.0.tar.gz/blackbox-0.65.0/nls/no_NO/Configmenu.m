$set 3 #Configmenu

$ #ConfigOptions
# Instillinger
$ #FocusModel
# Fokus-modell 
$ #WindowPlacement
# Vindusplassering
$ #ImageDithering
# Bildeutjevning
$ #OpaqueMove
# Vis vindusinnhold ved flytting
$ #FullMax
# Full maksimering
$ #FocusNew
# Fokuser nye vinduer
$ #FocusLast
# Fokuser vindu ved skrivebords-bytte
$ #DisableBindings
# Sl� av tastaturbindinger med Scroll Lock
$ #ClickToFocus
# Klikk for fokus
$ #SloppyFocus
# Slapp fokus
$ #AutoRaise
# Hev automatisk
$ #ClickRaise
# Klikk for � heve
$ #SmartRows
# Smart-plassering (rekker)
$ #SmartCols
# Smart-plassering (kolonner)
$ #Cascade
# Kaskade plassering
$ #LeftRight
# Fra venstre til h�yre
$ #RightLeft
# Fra h�yre til venstre
$ #TopBottom
# Topp til bunn
$ #BottomTop
# Bunn til topp
