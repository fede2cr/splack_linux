$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: feil ved forsp�rsel til X tjener.\n  \
en annen vindush�ndterer kj�rer allerede p� display %s.\n
$ #ManagingScreen
# BScreen::BScreen: h�ndterer skjerm %d, 0x%lx, fargedybde %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): kunne ikke laste skrifttypen '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): kunne ikke laste standard-skrifttypen.\n
$ #EmptyMenuFile
# %s: tom meny-fil\n
$ #xterm
# xterm
$ #Restart
# Omstart
$ #Exit
# Avslutt
$ #EXECError
# BScreen::parseMenuFile: [exec] feil, ingen meny-etikett og/eller kommando definert\n
$ #EXITError
# BScreen::parseMenuFile: [exit] feil, ingen meny-etikett definert\n
$ #STYLEError
# BScreen::parseMenuFile: [style] feil, ingen meny-etikett og/eller filnavn \
definert\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] feil, ingen meny-etikett definert\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] feil, filnavn ikke definert\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] feil, '%s' er ikke en normal fil\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] feil, ingen meny-etikett definert\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] feil, ingen meny-etikett definert\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] feil, ingen meny-etikett definert\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] feil, ingen katalog definert\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] feil, '%s' er ikke en katalog\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] feil, '%s' eksisterer ikke\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] feil, ingen meny-etikett definert\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# B: %4d x H: %4d

