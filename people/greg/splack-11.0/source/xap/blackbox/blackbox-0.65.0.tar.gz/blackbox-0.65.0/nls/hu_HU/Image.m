$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: hiba a k�p k�sz�t�sekor\n
$ #ErrorCreatingXImage
# BImage::renderXImage: hiba az XImage k�sz�t�sekor\n
$ #UnsupVisual
# BImage::renderXImage: nem t�mogatott visual\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: hiba a pixmap k�sz�t�sekor\n
$ #InvalidColormapSize
# BImageControl::BImageControl: helytelen colormap m�ret %d (%d/%d/%d) - cs�kkent�s\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: hiba a colormap lefoglal�s�n�l\n
$ #ColorAllocFail
# BImageControl::BImageControl: hiba a %d/%d/%d sz�n lefoglal�s�n�l\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - %d pixmaps felszabad�t�sa\n
$ #PixmapCacheLarge
# BImageControl::renderImage: a cache t�l nagy, �r�t�s\n
$ #ColorParseError
# BImageControl::getColor: hiba a sz�n elemz�s�n�l: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: hiba a sz�n lefoglal�s�n�l: '%s'\n
