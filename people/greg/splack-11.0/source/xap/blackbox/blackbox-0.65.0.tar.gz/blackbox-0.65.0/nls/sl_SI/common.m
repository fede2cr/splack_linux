$set 15 #Common

$ #Yes
# Da
$ #No
# Ne

$ #DirectionTitle
# Smer
$ #DirectionHoriz
# Vodoravno
$ #DirectionVert
# Navpi�no

$ #AlwaysOnTop
# Vselej na vrhu

$ #PlacementTitle
# Lega
$ #PlacementTopLeft
# Na vrhu in levo poravnano
$ #PlacementCenterLeft
# Navpi�no osredninjeno in levo poravnano
$ #PlacementBottomLeft
# Na dnu in levo poravnano
$ #PlacementTopCenter
# Na vrhu in osredinjeno
$ #PlacementBottomCenter
# Na dnu in osredinjeno
$ #PlacementTopRight
# Na vrhu in desno poravnano
$ #PlacementCenterRight
# Navpi�no osredinjeno in desno poravnano
$ #PlacementBottomRight
# Na dnu in desno poravnano

$ #AutoHide
# Samodejno skrivanje
