$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Richting
$ #SlitPlacement
# Plaats
