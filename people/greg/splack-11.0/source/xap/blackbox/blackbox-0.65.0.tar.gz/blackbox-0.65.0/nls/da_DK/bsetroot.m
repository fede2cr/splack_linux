$set 16 #bsetroot

$ #MustSpecify
# %s: fejl: specific�r en af f�lgende: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        sk�rmtilslutning\n\
  -mod <x> <y>             modula m�nster\n\
  -foreground, -fg <color> modula foregrundsfarve\n\
  -background, -bg <color> modula baggrundsfarve\n\n\
  -gradient <texture>      gradient tekstur\n\
  -from <color>            gradient start farve\n\
  -to <color>              gradient slut farve\n\n\
  -solid <color>           fast farve\n\n\
  -help                    vis denne hjlp og afslut\n
