$set 16 #bsetroot

$ #MustSpecify
# %s: fout: een van -solid, -mod, -gradient moet aangegeven worden\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <displaynaam>   display verbinding\n\
  -mod <x> <y>             modula patroon\n\
  -foreground, -fg <kleur> modula voorgrondkleur\n\
  -background, -bg <kleur> modula achtergrondkleur\n\n\
  -gradient <textuur>      gradi�nt textuur\n\
  -from <kleur>            gradi�nt beginkleur\n\
  -to <kleur>              gradi�nt eindkleur\n\n\
  -solid <kleur>           effen kleur\n\n\
  -help                    toon deze hulp tekst en stop\n

