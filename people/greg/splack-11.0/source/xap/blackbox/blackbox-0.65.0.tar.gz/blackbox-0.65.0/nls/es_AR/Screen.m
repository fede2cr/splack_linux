$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: ocurri� un error al cuestionar al servidor de X.\n Ya hay otro gestor de ventanas ejecut�ndose en la conexi�n al display %s.\n
$ #ManagingScreen
# BScreen::BScreen: administrando la pantalla %d usando visual 0x%lx, profundidad %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): no pude cargar la fuente '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): no pude cargar la fuente predeterminada.\n
$ #EmptyMenuFile
# %s: archivo de men� vac�o\n
$ #xterm
# xterm
$ #Restart
# Reiniciar
$ #Exit
# Salir
$ #EXECError
# BScreen::parseMenuFile: error en [exec], no se defini� una etiqueta ni/o un comando para el men�\n
$ #EXITError
# BScreen::parseMenuFile: error en [exit],  no se defini� una etiqueta para el men�\n
$ #STYLEError
# BScreen::parseMenuFile: error en [style],  no se defini� una etiqueta ni/o un nombre de archivo para el men�\n
$ #CONFIGError
# BScreen::parseMenuFile: error en [config],  no se defini� una etiqueta para el men�\n
$ #INCLUDEError
# BScreen::parseMenuFile: error en [include], no se defini� un nombre de archivo\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: error en [include], '%s' no es un archivo regular\n
$ #SUBMENUError
# BScreen::parseMenuFile: error en [submenu],  no se defini� una etiqueta para el men�\n
$ #RESTARTError
# BScreen::parseMenuFile: error en [restart],  no se defini� una etiqueta para el men�\n
$ #RECONFIGError
# BScreen::parseMenuFile: error en [reconfig],  no se defini� una etiqueta para el men�\n
$ #STYLESDIRError
# BScreen::parseMenuFile: error en [stylesdir/stylesmenu], no se defini� un directorio\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: error en [stylesdir/stylesmenu], '%s' no es un directorio\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: error en [stylesdir/stylesmenu], '%s' no existe\n
$ #WORKSPACESError
# BScreen::parseMenuFile: error en [workspaces],  no se defini� una etiqueta para el men�\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d
