$set 1 #BaseDisplay

$ #XError
# %s:  Erreur de X %s(%d) opcodes %d/%d\n  ressource 0x%lx\n
$ #SignalCaught
# %s: signal %d captur�\n
$ #ShuttingDown
# arr�t du programme\n
$ #Aborting
# annulation... g�n�ration du fichier core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: �chec de la connexion au serveur X\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: impossible d'attribuer close-on-exec � l'affichage\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): suppression d'une mauvaise fen�tre de la queue des �v�nements\n
