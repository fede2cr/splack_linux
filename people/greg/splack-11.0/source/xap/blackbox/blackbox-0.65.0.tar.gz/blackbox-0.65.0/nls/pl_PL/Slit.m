$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Kierunek
$ #SlitPlacement
# Po�o�enie
