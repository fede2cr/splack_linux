$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: maak window aan 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres mislukt\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: kan scherm voor root window 0x%lx niet vinden\n
$ #Unnamed
# Zonder titel
$ #MapRequest
# BlackboxWindow::mapRequestEvent() voor 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() voor 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reparent 0x%lx naar 0x%lx\n
