$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: creando 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres fall�\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: no se puede encontrar una pantalla para la ventana ra�z 0x%lx\n
$ #Unnamed
# Sin Nombre
$ #MapRequest
# BlackboxWindow::mapRequestEvent() para 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() para 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: cambiar padre de 0x%lx a 0x%lx\n
