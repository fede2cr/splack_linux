$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: k��da veidojot pikse�karti\n
$ #ErrorCreatingXImage
# BImage::renderXImage: k��da veidojot XImage\n
$ #UnsupVisual
# BImage::renderXImage: neatbalst�ts vizu�ls\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: k��da veidojot pikse�karti\n
$ #InvalidColormapSize
# BImageControl::BImageControl: neder�gs kr�su kartes izm�rs %d (%d/%d/%d) - reduc�ju\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: k��da pie��irot kr�su karti\n
$ #ColorAllocFail
# BImageControl::BImageControl: neizdev�s pie��irt kr�su %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pikse�kartes ke�s - atbr�voju %d pikse�kartes\n
$ #PixmapCacheLarge
# BImageControl::renderImage: ke�s ir liels, fors�ju att�r��anu\n
$ #ColorParseError
# BImageControl::getColor: kr�sas pars��anas k��da: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: kr�sas pie��ir�anas k��da: '%s'\n
