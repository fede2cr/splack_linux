$set 1 #BaseDisplay

$ #XError
# %s:  X feil: %s(%d) kode %d/%d\n  ressurs 0x%lx\n
$ #SignalCaught
# %s: signal %d fanget\n
$ #ShuttingDown
# Avslutter\n
$ #Aborting
# Avbryter... dumper kjerne\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: kunne ikke koble til X tjener.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: Kunne ikke markere skjermtilkobling som lukk-ved-eksekvering\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): fjerner korrupt vindu fra hendelsesk�\n
