$set 15 #Common

$ #Yes
# Tak 
$ #No
# Nie

$ #DirectionTitle
# Kierunek
$ #DirectionHoriz
# Poziomy
$ #DirectionVert
# Pionowy

$ #AlwaysOnTop
# Zawsze na wierzchu

$ #PlacementTitle
# Po�o�enie
$ #PlacementTopLeft
# G�rne Lewe
$ #PlacementCenterLeft
# �rodkowe Lewe
$ #PlacementBottomLeft
# Dolne Lewe
$ #PlacementTopCenter
# G�rne Centralne
$ #PlacementBottomCenter
# Dolne Centralne
$ #PlacementTopRight
# G�rne Prawe
$ #PlacementCenterRight
# �rodkowe Prawe
$ #PlacementBottomRight
# Dolne Prawe

$ #AutoHide
# Automatyczne ukrywanie
