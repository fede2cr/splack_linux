$set 10 #Windowmenu

$ #SendTo
# Enviar Para ...
$ #Shade
# Ocultar
$ #Iconify
# Minimizar
$ #Maximize
# Maximizar
$ #Raise
# Trazer pra Frente
$ #Lower
# Levar pra Traz
$ #Stick
# Fixar
$ #KillClient
# Matar Cliente
$ #Close
# Fechar
