$set 3 #Configmenu

$ #ConfigOptions
# Nastavitvene izbire
$ #FocusModel
# Na�in fokusiranja
$ #WindowPlacement
# Postavitev oken
$ #ImageDithering
# Prelivanje slik
$ #OpaqueMove
# Premikanje prosojnih oken
$ #FullMax
# Najve�je okno
$ #FocusNew
# Novo okno dobi fokus
$ #FocusLast
# Spremenjeni fokus okna na namizju
$ #ClickToFocus
# Za fokus kliknite
$ #SloppyFocus
# Povr�ni fokus
$ #AutoRaise
# Samodejno odkrivanje
$ #SmartRows
# Pametno postavljanje (vrstice)
$ #SmartCols
# Pametno postavljanje (stolpci)
$ #Cascade
# Kaskadno postavljanje
$ #LeftRight
# Od leve proti desni
$ #RightLeft
# Od desne proti levi
$ #TopBottom
# Od zgoraj navzdol
$ #BottomTop
# Od spodaj navzgor
