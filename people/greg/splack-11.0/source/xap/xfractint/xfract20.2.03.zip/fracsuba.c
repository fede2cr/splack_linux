
#include "port.h"
#include "prototyp.h"

int FManOWarfpFractal(void) {return(0);}
int FJuliafpFractal(void) {return(0);}
int FBarnsley1FPFractal(void) {return(0);}
int FBarnsley2FPFractal(void) {return(0);}
int FLambdaFPFractal(void) {return(0);}
