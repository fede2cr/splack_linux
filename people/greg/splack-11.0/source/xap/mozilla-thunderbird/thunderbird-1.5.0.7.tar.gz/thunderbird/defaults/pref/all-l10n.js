//@line 36 "/builds/tinderbox/Tb-Mozilla1.8.0-Release/Linux_2.4.18-14_Depend/mozilla/mail/locales/../../mail/locales/en-US/all-l10n.js"

//@line 38 "/builds/tinderbox/Tb-Mozilla1.8.0-Release/Linux_2.4.18-14_Depend/mozilla/mail/locales/../../mail/locales/en-US/all-l10n.js"

pref("general.useragent.locale", "en-US");
