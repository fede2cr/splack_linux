For information about installing, running and configuring Thunderbird
including a list of known issues and troubleshooting information, 
refer to: http://getthunderbird.com/releases/

