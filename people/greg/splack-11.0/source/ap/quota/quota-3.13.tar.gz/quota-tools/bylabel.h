#ifndef _BYLABEL_H_
#define _BYLABEL_H_
const char *get_device_name(const char *item);
#endif /* _BYLABEL_H_ */
