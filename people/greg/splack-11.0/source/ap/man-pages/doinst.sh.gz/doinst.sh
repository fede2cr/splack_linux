#!/bin/sh
if [ ! -e usr/man/whatis ]; then
  mv usr/man/whatis.sample usr/man/whatis
elif [ "`cat usr/man/whatis | md5sum`" = "`cat usr/man/whatis.sample | md5sum`" ]; then # toss the redundant copy
  rm usr/man/whatis.sample
fi
