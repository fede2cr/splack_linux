#!/bin/sh

srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.

ORIGDIR=`pwd`
pushd $srcdir
autoheader
autoconf
popd
$srcdir/configure "$@"
