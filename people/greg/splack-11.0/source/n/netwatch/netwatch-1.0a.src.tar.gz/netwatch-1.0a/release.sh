#!/bin/bash
VER=`cat version`
make clean
make tar
./configure
sed "s/Src/Bin/g" gh.c > ttt
/bin/rm gh.c
mv ttt gh.c
make
cp ../Makefile.netwatch.bin Makefile
sed "s/XXXX/$VER/g" Makefile > ttt
/bin/rm Makefile
mv ttt Makefile
/bin/rm *.in conf* *.o *.c *.awk *.gen *.ports *.h Mak*common
/bin/rm -r IANA
make tar
cp *.lsm ..
