void set_barptr(char **barptr, char *entry,
    time_t *starttime, char *spanbr, size_t size,
    WINDOW *win, int *cleared, int x);
