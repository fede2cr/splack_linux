( cd usr/bin ; rm -rf rn )
( cd usr/bin ; ln -sf  trn rn )
