ccflags='-A nansi'
d_ignoreorg='define'
