set `echo $libswanted | sed -e 's/ socket / inet /'`
libswanted="$*"
