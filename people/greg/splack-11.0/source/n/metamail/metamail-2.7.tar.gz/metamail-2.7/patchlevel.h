/* This is the metamail distribution, version number as given below.

Version history:

  Version 1.X was Bellcore-internal and pre-MIME.
  Version 2.0 was the first MIME-compliant release, also Bellcore-internal.
  Version 2.1 was the first public release, January 1992.
  Version 2.2 was the second public release, April 1992.  Major changes included:
      -- Ports to UNIX variants & MS-DOS.
      -- The new "mailto" program
      -- Innumerable smaller fixes & enhancements
  Version 2.3 was the June, 1992 release, with many more patches and 
      enhancements, including a Commodore Amiga port.
  Version 2.4 was the December, 1992 release, including many bug fixes and a vastly expanded (and now separately packaged) contrib directory.
  Version 2.5 was the June, 1993 release, with mostly just bug fixes from 2.4.
  Version 2.6 was the July, 1993 release, with important bug fixes from 2.5.
  Version 2.7 was the February, 1994 release, mostly bug fixes.
*/
#define MM_VERSTRING "2.7"
