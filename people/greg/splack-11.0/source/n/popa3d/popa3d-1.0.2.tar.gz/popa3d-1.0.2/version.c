/*
 * popa3d version information.
 */

char popa3d_version[] = "1.0.2";
char popa3d_date[] = "2006/05/23";
