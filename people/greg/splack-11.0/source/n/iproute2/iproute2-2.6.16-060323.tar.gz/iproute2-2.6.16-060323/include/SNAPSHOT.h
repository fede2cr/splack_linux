static char SNAPSHOT[] = "060323";
