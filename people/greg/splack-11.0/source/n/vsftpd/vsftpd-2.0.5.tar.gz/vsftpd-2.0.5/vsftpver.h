#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "2.0.5"

#endif /* VSF_VERSION_H */

