#! /usr/bin/perl

# A simple PERL script to open a file and keep it open. The reason I wrote 
# this was to verify that rmmod indeed doesn't work when the device file
# is open.

open(FILE, $ARGV[0]) || die ("Can't open $ARGV[0]");

print "Opened\n";

sleep 60;
print <FILE>;

close(FILE);
