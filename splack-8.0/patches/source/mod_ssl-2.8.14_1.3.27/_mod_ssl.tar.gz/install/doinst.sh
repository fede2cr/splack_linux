if [ ! -f etc/apache/mod_ssl.conf ]; then
   cp -a etc/apache/mod_ssl.conf.example etc/apache/mod_ssl.conf
elif [ "`cat etc/apache/mod_ssl.conf 2> /dev/null`" = "" ]; then
   cp -a etc/apache/mod_ssl.conf.example etc/apache/mod_ssl.conf
fi
