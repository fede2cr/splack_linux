cd etc-incoming
for file in * */* ; do
 if [ ! -d file ]; then # file is not a directory
  if [ ! -r ../etc/$file ]; then # file isn't already in /etc, so copy it.
   cp -a $file ../etc/$file
  fi
 fi
done
cd ..
rm -rf etc-incoming
