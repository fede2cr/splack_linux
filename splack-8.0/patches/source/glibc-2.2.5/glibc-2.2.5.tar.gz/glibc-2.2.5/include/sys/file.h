#ifndef _SYS_FILE_H
#include <misc/sys/file.h>

/* Now define the internal interfaces.  */
extern int __flock (int __fd, int __operation);
#endif
