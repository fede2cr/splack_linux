#ifndef	_STDIO_EXT_H

# include <stdio-common/stdio_ext.h>

#endif
