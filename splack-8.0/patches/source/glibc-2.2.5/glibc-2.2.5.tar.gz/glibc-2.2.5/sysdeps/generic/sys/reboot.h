/* This file should define RB_* macros to be used as flag
   bits in the argument to the `reboot' system call.  */

#ifndef _SYS_REBOOT_H
#define _SYS_REBOOT_H

#define RB_AUTOBOOT	0

#endif	/* <sys/reboot.h> */
