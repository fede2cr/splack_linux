#ifndef _MATH_H
#error "Never use <bits/nan.h> directly; include <math.h> instead."
#endif

/* This file should define `NAN' on machines that have such things.  */
