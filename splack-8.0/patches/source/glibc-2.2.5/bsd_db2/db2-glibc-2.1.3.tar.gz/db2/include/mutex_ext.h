/* DO NOT EDIT: automatically built by dist/distrib. */
#ifndef _mutex_ext_h_
#define _mutex_ext_h_
int __db_mutex_init __P((db_mutex_t *, u_int32_t));
int __db_mutex_lock __P((db_mutex_t *, int));
int __db_mutex_unlock __P((db_mutex_t *, int));
#endif /* _mutex_ext_h_ */
