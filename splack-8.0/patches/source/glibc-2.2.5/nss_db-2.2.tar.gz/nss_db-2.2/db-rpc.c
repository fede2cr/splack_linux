#define EXTERN_PARSER
#define GENERIC "db-XXX.c"
#include "files-rpc.c"
