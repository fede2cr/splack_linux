if [ ! -r var/spool/atjobs/.SEQ ]; then
  touch var/spool/atjobs/.SEQ
  chmod 600 var/spool/atjobs/.SEQ
  chown daemon.daemon var/spool/atjobs/.SEQ
fi
( cd usr/bin ; rm -rf atq )
( cd usr/bin ; ln -sf at atq )
( cd usr/bin ; rm -rf atrm )
( cd usr/bin ; ln -sf at atrm )
( cd usr/man/man1 ; rm -rf atq.1.gz )
( cd usr/man/man1 ; ln -sf at.1.gz atq.1.gz )
( cd usr/man/man1 ; rm -rf atrm.1.gz )
( cd usr/man/man1 ; ln -sf at.1.gz atrm.1.gz )
( cd usr/man/man1 ; rm -rf batch.1.gz )
( cd usr/man/man1 ; ln -sf at.1.gz batch.1.gz )
