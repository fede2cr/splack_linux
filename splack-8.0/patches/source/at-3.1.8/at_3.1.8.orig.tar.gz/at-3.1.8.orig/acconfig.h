
@BOTTOM@

/* Define location of spool directories */

#undef SPOOLDIR

/* Define location for PID file */

#undef PIDFILE

/* Define mail command for sending; use at most one */

#undef MAILX

#undef SENDMAIL

#undef MAILC

/* Where do we place out input directories? */

#undef ATJOB_DIR

/* Where do we spool our output? */

#undef ATSPOOL_DIR

/* What's the name of our PID file? */

#undef PIDFILE

/* Default queues for at and batch */

#undef DEFAULT_AT_QUEUE

#undef DEFAULT_BATCH_QUEUE

#undef HAVE_ATTRIBUTE_NORETURN
