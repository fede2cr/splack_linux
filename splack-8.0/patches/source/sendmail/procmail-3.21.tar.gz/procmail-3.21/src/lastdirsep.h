/*$Id: lastdirsep.h,v 1.2 1994/08/18 18:12:39 berg Exp $*/

char
 *lastdirsep P((const char*filename));
