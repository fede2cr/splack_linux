# If a custom aliases file exists, we don't want to overwrite it, but
# we'll leave the new standard aliases file in /etc/mail so maybe the
# sysadmin will notice it. :^)
if [ -r etc/mail/aliases ]; then
  if [ "`cat etc/mail/aliases`" = "# Put any sendmail aliases in here" ]; then
    mv etc/mail/aliases.new etc/mail/aliases
  fi
else
  mv etc/mail/aliases.new etc/mail/aliases
fi
if [ ! -r etc/mail/aliases.db ]; then
  mv etc/mail/aliases.db.new etc/mail/aliases.db
else
  rm etc/mail/aliases.db.new
fi
rm -f usr/sbin/sendmail
mv usr/sbin/sendmail.new usr/sbin/sendmail
( cd usr/bin ; rm -rf newaliases )
( cd usr/bin ; ln -sf /usr/sbin/sendmail newaliases )
( cd usr/bin ; rm -rf mailq )
( cd usr/bin ; ln -sf /usr/sbin/sendmail mailq )
( cd usr/bin ; rm -rf hoststat )
( cd usr/bin ; ln -sf /usr/sbin/sendmail hoststat )
( cd usr/bin ; rm -rf purgestat )
( cd usr/bin ; ln -sf /usr/sbin/sendmail purgestat )
( cd usr/lib ; rm -rf sendmail )
( cd usr/lib ; ln -sf /usr/sbin/sendmail sendmail )
( cd usr/bin ; rm -rf sendmail )
( cd usr/bin ; ln -sf /usr/sbin/sendmail sendmail )
chroot . /usr/bin/newaliases 1> /dev/null
