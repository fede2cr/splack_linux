#ifndef __PCCTS_ASSERT_H__
#define __PCCTS_ASSERT_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <cassert>
#else
#include <assert.h>
#endif

#endif
