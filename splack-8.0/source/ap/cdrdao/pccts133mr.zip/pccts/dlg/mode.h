#define START 0
#define ACT 1
#define ACTION_COMMENTS 2
#define ACTION_CPP_COMMENTS 3
