#ifndef _GDEVCD8_H
#define _GDEVCD8_H

/* a couple of definitions need in gdevcd8.c */

/* this holds the initialisation data of the hp850 */
struct hp850_cmyk_init {
   byte a[26];
};

#endif
